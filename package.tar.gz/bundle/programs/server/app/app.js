var require = meteorInstall({"lib":{"routes.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// lib/routes.js                                                                                             //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
/* Regular path routes */                                                                                    // 1
                                                                                                             //
FlowRouter.route('/dev', {                                                                                   // 3
	name: 'dev',                                                                                                // 4
	action: function () {                                                                                       // 5
		function action() {                                                                                        // 3
			BlazeLayout.render('gallery'); //Testing Area                                                             // 6
		}                                                                                                          // 7
                                                                                                             //
		return action;                                                                                             // 3
	}()                                                                                                         // 3
});                                                                                                          // 3
                                                                                                             //
FlowRouter.route('/', {                                                                                      // 10
	name: 'home',                                                                                               // 11
	action: function () {                                                                                       // 12
		function action() {                                                                                        // 10
			FlowRouter.go('index');                                                                                   // 13
		}                                                                                                          // 14
                                                                                                             //
		return action;                                                                                             // 10
	}()                                                                                                         // 10
});                                                                                                          // 10
                                                                                                             //
FlowRouter.route('/index', {                                                                                 // 17
	name: 'index',                                                                                              // 18
	action: function () {                                                                                       // 19
		function action() {                                                                                        // 17
			BlazeLayout.render('index');                                                                              // 20
		}                                                                                                          // 21
                                                                                                             //
		return action;                                                                                             // 17
	}()                                                                                                         // 17
});                                                                                                          // 17
                                                                                                             //
FlowRouter.route('/admin', {                                                                                 // 24
	name: 'admin',                                                                                              // 25
	action: function () {                                                                                       // 26
		function action() {                                                                                        // 24
			BlazeLayout.render('AdminSplash', { main: 'AdminHome' });                                                 // 27
		}                                                                                                          // 28
                                                                                                             //
		return action;                                                                                             // 24
	}()                                                                                                         // 24
});                                                                                                          // 24
                                                                                                             //
FlowRouter.route('/admin/product/add', {                                                                     // 31
	name: 'AdminAddProduct',                                                                                    // 32
	action: function () {                                                                                       // 33
		function action() {                                                                                        // 31
			BlazeLayout.render('AdminSplash', { main: 'AdminAddProduct' });                                           // 34
		}                                                                                                          // 35
                                                                                                             //
		return action;                                                                                             // 31
	}()                                                                                                         // 31
});                                                                                                          // 31
                                                                                                             //
FlowRouter.route('/admin/product/all', {                                                                     // 38
	name: 'AdminAllProduct',                                                                                    // 39
	action: function () {                                                                                       // 40
		function action() {                                                                                        // 38
			BlazeLayout.render('AdminSplash', { main: 'AdminSeeAllProducts' });                                       // 41
		}                                                                                                          // 42
                                                                                                             //
		return action;                                                                                             // 38
	}()                                                                                                         // 38
});                                                                                                          // 38
                                                                                                             //
/* Single Product Admin Route */                                                                             // 45
                                                                                                             //
FlowRouter.route('/admin/product/:id', {                                                                     // 47
	name: 'AdminSingleProductFull',                                                                             // 48
	action: function () {                                                                                       // 49
		function action() {                                                                                        // 47
			BlazeLayout.render('AdminSplash', { main: 'AdminSingleProductFull' });                                    // 50
		}                                                                                                          // 51
                                                                                                             //
		return action;                                                                                             // 47
	}()                                                                                                         // 47
});                                                                                                          // 47
                                                                                                             //
/* Single Product Route */                                                                                   // 54
                                                                                                             //
FlowRouter.route('/product/:id', {                                                                           // 56
	name: 'single',                                                                                             // 57
	action: function () {                                                                                       // 58
		function action() {                                                                                        // 56
			BlazeLayout.render('singleProduct');                                                                      // 59
		}                                                                                                          // 60
                                                                                                             //
		return action;                                                                                             // 56
	}()                                                                                                         // 56
});                                                                                                          // 56
                                                                                                             //
FlowRouter.route('/search', {                                                                                // 63
	name: 'search',                                                                                             // 64
	action: function () {                                                                                       // 65
		function action() {                                                                                        // 63
			BlazeLayout.render('productSearch');                                                                      // 66
		}                                                                                                          // 67
                                                                                                             //
		return action;                                                                                             // 63
	}()                                                                                                         // 63
});                                                                                                          // 63
                                                                                                             //
FlowRouter.route('/special', {                                                                               // 70
	name: 'special',                                                                                            // 71
	action: function () {                                                                                       // 72
		function action() {                                                                                        // 70
			BlazeLayout.render('special');                                                                            // 73
		}                                                                                                          // 74
                                                                                                             //
		return action;                                                                                             // 70
	}()                                                                                                         // 70
});                                                                                                          // 70
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"Images.js":["meteor/ostrio:files",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// collections/Images.js                                                                                     //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var FilesCollection;module.import('meteor/ostrio:files',{"FilesCollection":function(v){FilesCollection=v}});
                                                                                                             //
Images = new FilesCollection({                                                                               // 5
  storagePath: '../../../data', // CHECK IF IT WORKS AFTER DEPLOYMENT                                        // 6
  downloadRoute: '/files/images',                                                                            // 7
  collectionName: 'Images',                                                                                  // 8
  chunkSize: 2048 * 2048,                                                                                    // 9
  throttle: 2048 * 2048,                                                                                     // 10
  permissions: 777,                                                                                          // 11
  allowClientCode: true,                                                                                     // 12
  cacheControl: 'public, max-age=31536000',                                                                  // 13
  onbeforeunloadMessage: function () {                                                                       // 14
    function onbeforeunloadMessage() {                                                                       // 14
      return 'Upload is still in progress! Upload will be aborted if you leave this page!';                  // 15
    }                                                                                                        // 16
                                                                                                             //
    return onbeforeunloadMessage;                                                                            // 14
  }(),                                                                                                       // 14
  onBeforeUpload: function () {                                                                              // 17
    function onBeforeUpload(file) {                                                                          // 17
      // Allow upload files under 10MB, and only in png/jpg/jpeg formats                                     // 18
      if (file.size <= 10485760 && /png|jpg|jpeg/i.test(file.ext)) {                                         // 19
        return true;                                                                                         // 20
      } else {                                                                                               // 21
        return 'Please upload image, with size equal or less than 10MB';                                     // 22
      }                                                                                                      // 23
    }                                                                                                        // 24
                                                                                                             //
    return onBeforeUpload;                                                                                   // 17
  }(),                                                                                                       // 17
  downloadCallback: function () {                                                                            // 25
    function downloadCallback(fileObj) {                                                                     // 25
      if (this.params.query.download == 'true') {                                                            // 26
        // Increment downloads counter                                                                       // 27
        Images.update(fileObj._id, { $inc: { 'meta.downloads': 1 } });                                       // 28
      }                                                                                                      // 30
      // Must return true to continue download                                                               // 31
      return true;                                                                                           // 32
    }                                                                                                        // 33
                                                                                                             //
    return downloadCallback;                                                                                 // 25
  }()                                                                                                        // 25
});                                                                                                          // 5
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"Products.js":["meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// collections/Products.js                                                                                   //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});                                  // 1
                                                                                                             //
Products = new Mongo.Collection('products');                                                                 // 4
                                                                                                             //
/* Allows clients to add entries */                                                                          // 6
Products.allow({                                                                                             // 7
	insert: function () {                                                                                       // 8
		function insert() {                                                                                        // 8
			return true;                                                                                              // 9
		}                                                                                                          // 10
                                                                                                             //
		return insert;                                                                                             // 8
	}(),                                                                                                        // 8
	update: function () {                                                                                       // 11
		function update() {                                                                                        // 11
			return true;                                                                                              // 12
		}                                                                                                          // 13
                                                                                                             //
		return update;                                                                                             // 11
	}()                                                                                                         // 11
});                                                                                                          // 7
                                                                                                             //
Meteor.methods({                                                                                             // 16
	deleteProduct: function () {                                                                                // 17
		function deleteProduct(id) {                                                                               // 17
			Products.remove(id);                                                                                      // 18
		}                                                                                                          // 19
                                                                                                             //
		return deleteProduct;                                                                                      // 17
	}()                                                                                                         // 17
});                                                                                                          // 16
                                                                                                             //
/* Collection Atributes */                                                                                   // 22
                                                                                                             //
PictureLink = new SimpleSchema({                                                                             // 24
	picture: {                                                                                                  // 25
		type: String,                                                                                              // 26
		//optional: true,                                                                                          // 27
		autoform: {                                                                                                // 28
			afFieldInput: {                                                                                           // 29
				type: 'fileUpload',                                                                                      // 30
				collection: 'Images',                                                                                    // 31
				uploadTemplate: 'uploadForm' }                                                                           // 32
		}                                                                                                          // 28
	}                                                                                                           // 25
});                                                                                                          // 24
                                                                                                             //
ProductsSchema = new SimpleSchema({                                                                          // 39
	ref: {                                                                                                      // 40
		type: String,                                                                                              // 41
		label: "Referência",                                                                                       // 42
		unique: true                                                                                               // 43
	},                                                                                                          // 40
	name: {                                                                                                     // 45
		type: String,                                                                                              // 46
		label: "Nome"                                                                                              // 47
	},                                                                                                          // 45
	brand: {                                                                                                    // 49
		type: String,                                                                                              // 50
		label: "Marca"                                                                                             // 51
	},                                                                                                          // 49
	desc: {                                                                                                     // 53
		type: String,                                                                                              // 54
		label: "Descrição"                                                                                         // 55
	},                                                                                                          // 53
	type: {                                                                                                     // 57
		type: String,                                                                                              // 58
		label: "Tipo"                                                                                              // 59
	},                                                                                                          // 57
	gender: {                                                                                                   // 61
		type: String,                                                                                              // 62
		label: "Género",                                                                                           // 63
		allowedValues: ['Male', 'Female', 'Both']                                                                  // 64
	},                                                                                                          // 61
	season: {                                                                                                   // 66
		type: String,                                                                                              // 67
		label: "Anos"                                                                                              // 68
	},                                                                                                          // 66
	spotlight: {                                                                                                // 71
		type: Boolean,                                                                                             // 72
		label: "Em destaque"                                                                                       // 73
	},                                                                                                          // 71
	special: {                                                                                                  // 75
		type: Boolean,                                                                                             // 76
		label: "Projeto Pessoal"                                                                                   // 77
	},                                                                                                          // 75
	available: {                                                                                                // 79
		type: Boolean,                                                                                             // 80
		label: "Disponível"                                                                                        // 81
	},                                                                                                          // 79
	pictures: {                                                                                                 // 84
		type: [PictureLink]                                                                                        // 85
	}                                                                                                           // 84
});                                                                                                          // 39
                                                                                                             //
Products.attachSchema(ProductsSchema);                                                                       // 89
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"Users.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// collections/Users.js                                                                                      //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
//import { Meteor } from 'meteor/meteor';                                                                    // 1
//import { AccountsTemplates } from 'meteor/accounts-base';                                                  // 2
                                                                                                             //
var pwd = AccountsTemplates.removeField('password');                                                         // 4
AccountsTemplates.removeField('email');                                                                      // 5
AccountsTemplates.addFields([{                                                                               // 6
  _id: "username",                                                                                           // 8
  type: "text",                                                                                              // 9
  displayName: "username",                                                                                   // 10
  required: true,                                                                                            // 11
  minLength: 5                                                                                               // 12
}, {                                                                                                         // 7
  _id: 'email',                                                                                              // 15
  type: 'email',                                                                                             // 16
  required: true,                                                                                            // 17
  displayName: "email",                                                                                      // 18
  re: /.+@(.+){2,}\.(.+){2,}/,                                                                               // 19
  errStr: 'Invalid email'                                                                                    // 20
}, {                                                                                                         // 14
  _id: 'username_and_email',                                                                                 // 23
  type: 'text',                                                                                              // 24
  required: true,                                                                                            // 25
  displayName: "Login"                                                                                       // 26
}, pwd, {                                                                                                    // 22
  _id: 'date',                                                                                               // 30
  type: 'hidden',                                                                                            // 31
  autoValue: function () {                                                                                   // 32
    function autoValue() {                                                                                   // 32
      return new Date();                                                                                     // 33
    }                                                                                                        // 34
                                                                                                             //
    return autoValue;                                                                                        // 32
  }()                                                                                                        // 32
}]);                                                                                                         // 29
                                                                                                             //
AccountsTemplates.configure({                                                                                // 38
  onSubmitHook: function () {                                                                                // 39
    function onSubmitHook() {                                                                                // 39
      FlowRouter.reload();                                                                                   // 40
    }                                                                                                        // 41
                                                                                                             //
    return onSubmitHook;                                                                                     // 39
  }()                                                                                                        // 39
});                                                                                                          // 38
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"i18n":{"en.i18n.json":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// i18n/en.i18n.json                                                                                         //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
// integrate the fallback language translations 
translations = {};
translations[namespace] = {"nav-search":"Search","nav-personalprojects":"Personal Projects","nav-about":"About us","nav-contacts":"Contacts","index-spotlight":"Spotlight","index-seeallprocucts":"See all products","index-brands":"Our brands","index-aboutus":"About us","index-aboutus-long":"Bacon ipsum dolor amet burgdoggen frankfurter tri-tip, short loin drumstick strip steak filet mignon pork chop beef ribs andouille alcatra salami sirloin biltong. Chicken flank frankfurter pastrami. Tongue pig chicken leberkas shoulder filet mignon pancetta pastrami burgdoggen doner. Shank strip steak beef kielbasa tri-tip swine sausage. Flank pork loin beef ribs, tongue prosciutto alcatra pork belly kielbasa. Flank ham hock filet mignon bresaola pancetta cow pork.","index-contacts":"Get in touch","search-filterby":"Filter by:","search-brand":"Brand","search-type":"Type","search-season":"Season","search-personalproject":"(Personal Project)","special-about":"Bacon ipsum dolor amet burgdoggen frankfurter tri-tip, short loin drumstick strip steak filet mignon pork chop beef ribs andouille alcatra salami sirloin biltong. Chicken flank frankfurter pastrami. Tongue pig chicken leberkas shoulder filet mignon pancetta pastrami burgdoggen doner. Shank strip steak beef kielbasa tri-tip swine sausage. Flank pork loin beef ribs, tongue prosciutto alcatra pork belly kielbasa. Flank ham hock filet mignon bresaola pancetta cow pork.","productcard-seemore":"See more about this","loading":"Loading..."};
TAPi18n._loadLangFileObject("en", translations);
TAPi18n._registerServerTranslator("en", namespace);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pt.i18n.json":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// i18n/pt.i18n.json                                                                                         //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["pt"] = ["Portuguese (Portugal)","Português"];
if(_.isUndefined(TAPi18n.translations["pt"])) {
  TAPi18n.translations["pt"] = {};
}

if(_.isUndefined(TAPi18n.translations["pt"][namespace])) {
  TAPi18n.translations["pt"][namespace] = {};
}

_.extend(TAPi18n.translations["pt"][namespace], {"nav-search":"Pesquisar","nav-personalprojects":"Projetos Pessoais","nav-about":"Sobre nós","nav-contacts":"Contactos","index-spotlight":"Peças em destaque","index-seeallprocucts":"Ver todos os nossos produtos","index-brands":"As nossas marcas","index-aboutus":"Sobre nós","index-aboutus-long":"Bacon ipsum dolor amet burgdoggen frankfurter tri-tip, short loin drumstick strip steak filet mignon pork chop beef ribs andouille alcatra salami sirloin biltong. Chicken flank frankfurter pastrami. Tongue pig chicken leberkas shoulder filet mignon pancetta pastrami burgdoggen doner. Shank strip steak beef kielbasa tri-tip swine sausage. Flank pork loin beef ribs, tongue prosciutto alcatra pork belly kielbasa. Flank ham hock filet mignon bresaola pancetta cow pork.","index-contacts":"Entre em contacto connosco","search-filterby":"Filtrar por:","search-brand":"Marca","search-type":"Tipo","search-season":"Época","search-personalproject":"(Projeto Pessoal)","special-about":"Bacon ipsum dolor amet burgdoggen frankfurter tri-tip, short loin drumstick strip steak filet mignon pork chop beef ribs andouille alcatra salami sirloin biltong. Chicken flank frankfurter pastrami. Tongue pig chicken leberkas shoulder filet mignon pancetta pastrami burgdoggen doner. Shank strip steak beef kielbasa tri-tip swine sausage. Flank pork loin beef ribs, tongue prosciutto alcatra pork belly kielbasa. Flank ham hock filet mignon bresaola pancetta cow pork.","productcard-seemore":"Ver mais informação","loading":"A carregar..."});
TAPi18n._registerServerTranslator("pt", namespace);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"init.js":["meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/init.js                                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});                                  // 1
                                                                                                             //
Meteor.startup(function () {                                                                                 // 3
		// Create Admin Account                                                                                    // 4
		/*if ( Meteor.Users.find().count() === 0 ) {                                                               // 5
      var admin = Accounts.createUser({                                                                      //
          username: 'admin',                                                                                 //
          email: "admin@admin.com",                                                                          //
          password: 'admin',                                                                                 //
      });                                                                                                    //
  };                                                                                                         //
  Roles.addUsersToRoles(admin, 'admin', 'default-group');*/                                                  //
});                                                                                                          // 13
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publish.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/publish.js                                                                                         //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
/* Anounces to clients the collections available */                                                          // 1
/* Can be limited to specific entries in the collection */                                                   // 2
                                                                                                             //
/*Meteor.publish('products', function(){                                                                     // 4
	return Products.find();                                                                                     //
});*/                                                                                                        //
                                                                                                             //
//import Images from 'Images.js';                                                                            // 8
                                                                                                             //
Meteor.publish('singleProduct', function (id) {                                                              // 10
  check(id, String);                                                                                         // 11
  return Products.find({ _id: id });                                                                         // 12
});                                                                                                          // 13
                                                                                                             //
/* Image Testing */                                                                                          // 15
Meteor.publish('files.images.all', function () {                                                             // 16
  return Images.find().cursor;                                                                               // 17
});                                                                                                          // 18
                                                                                                             //
Meteor.publish('files.images.multiple', function (id) {                                                      // 20
  check(id, String);                                                                                         // 21
  var p = Products.findOne({ _id: id });                                                                     // 22
  var imageArray = [];                                                                                       // 23
  for (i = 0; i < p.pictures.length; i++) {                                                                  // 24
    if (p.pictures[i].picture) imageArray.push(p.pictures[i].picture);                                       // 26
  };                                                                                                         // 28
                                                                                                             //
  return Images.find({ "_id": { "$in": imageArray } }).cursor;                                               // 30
});                                                                                                          // 31
                                                                                                             //
Meteor.publish('singleImage', function (id) {                                                                // 33
  check(id, String);                                                                                         // 34
  var p = Products.findOne({ _id: id });                                                                     // 35
  return Images.find({ _id: p.picture }).cursor;                                                             // 36
});                                                                                                          // 37
                                                                                                             //
/* Search Testing */                                                                                         // 39
Meteor.publish('products', function (search) {                                                               // 40
  check(search, Match.OneOf(String, null, undefined));                                                       // 41
                                                                                                             //
  var query = {},                                                                                            // 43
      projection = { limit: 10, sort: { name: 1 } };                                                         // 43
                                                                                                             //
  if (search) {                                                                                              // 46
    var regex = new RegExp(search, 'i');                                                                     // 47
                                                                                                             //
    query = {                                                                                                // 49
      $or: [{ name: regex }, { brand: regex }, { type: regex }, { decade: regex }]                           // 50
    };                                                                                                       // 49
                                                                                                             //
    projection.limit = 100;                                                                                  // 58
  }                                                                                                          // 59
                                                                                                             //
  return Products.find(query, projection);                                                                   // 61
});                                                                                                          // 62
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"search.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/search.js                                                                                          //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
SearchSource.defineSource('products', function (searchText, options) {                                       // 1
                                                                                                             //
  //console.log(options);                                                                                    // 3
                                                                                                             //
  var filter = options;                                                                                      // 5
                                                                                                             //
  var brands = [];                                                                                           // 7
  var types = [];                                                                                            // 8
  var seasons = [];                                                                                          // 9
                                                                                                             //
  for (i = 0; i < filter.brand.length; i++) {                                                                // 11
    brands.push(buildRegExp(filter.brand[i]));                                                               // 13
  }                                                                                                          // 14
  for (i = 0; i < filter.type.length; i++) {                                                                 // 15
    types.push(buildRegExp(filter.type[i]));                                                                 // 17
  }                                                                                                          // 18
  for (i = 0; i < filter.season.length; i++) {                                                               // 19
    seasons.push(filter.season[i]);                                                                          // 21
  }                                                                                                          // 22
                                                                                                             //
  var options = { sort: { isoScore: -1 }, limit: 20 };                                                       // 24
                                                                                                             //
  if (searchText) {                                                                                          // 26
                                                                                                             //
    var selector2 = { $and: [{ name: buildRegExp(filter.name) }, { brand: { $in: brands } }, { type: { $in: types } }, { season: { $in: seasons } }] };
                                                                                                             //
    return Products.find(selector2, options).fetch();                                                        // 35
  } else {                                                                                                   // 36
    return Products.find({}, options).fetch();                                                               // 37
  }                                                                                                          // 38
});                                                                                                          // 39
                                                                                                             //
function buildRegExp(searchText) {                                                                           // 41
  // this is a dumb implementation                                                                           // 42
  var parts = searchText.trim().split(/[ \-\:]+/);                                                           // 43
  return new RegExp("(" + parts.join('|') + ")", "ig");                                                      // 44
}                                                                                                            // 45
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/routes.js");
require("./collections/Images.js");
require("./collections/Products.js");
require("./collections/Users.js");
require("./i18n/en.i18n.json");
require("./i18n/pt.i18n.json");
require("./server/init.js");
require("./server/publish.js");
require("./server/search.js");
//# sourceMappingURL=app.js.map
