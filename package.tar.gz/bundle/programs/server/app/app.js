var require = meteorInstall({"lib":{"routes.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// lib/routes.js                                                                                             //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
/* Regular path routes */                                                                                    // 1
                                                                                                             //
FlowRouter.route('/dev', {                                                                                   // 3
	name: 'dev',                                                                                                // 4
	action: function () {                                                                                       // 5
		function action() {                                                                                        // 3
			BlazeLayout.render(''); //Testing Area                                                                    // 6
		}                                                                                                          // 7
                                                                                                             //
		return action;                                                                                             // 3
	}()                                                                                                         // 3
});                                                                                                          // 3
                                                                                                             //
FlowRouter.route('/', {                                                                                      // 10
	name: 'home',                                                                                               // 11
	action: function () {                                                                                       // 12
		function action() {                                                                                        // 10
			FlowRouter.go('index');                                                                                   // 13
		}                                                                                                          // 14
                                                                                                             //
		return action;                                                                                             // 10
	}()                                                                                                         // 10
});                                                                                                          // 10
                                                                                                             //
FlowRouter.route('/index', {                                                                                 // 17
	name: 'index',                                                                                              // 18
	action: function () {                                                                                       // 19
		function action() {                                                                                        // 17
			BlazeLayout.render('index');                                                                              // 20
		}                                                                                                          // 21
                                                                                                             //
		return action;                                                                                             // 17
	}()                                                                                                         // 17
});                                                                                                          // 17
                                                                                                             //
FlowRouter.route('/admin', {                                                                                 // 24
	name: 'admin',                                                                                              // 25
	action: function () {                                                                                       // 26
		function action() {                                                                                        // 24
			BlazeLayout.render('AdminSplash', { main: 'AdminHome' });                                                 // 27
		}                                                                                                          // 28
                                                                                                             //
		return action;                                                                                             // 24
	}()                                                                                                         // 24
});                                                                                                          // 24
                                                                                                             //
FlowRouter.route('/admin/product/add', {                                                                     // 31
	name: 'AdminAddProduct',                                                                                    // 32
	action: function () {                                                                                       // 33
		function action() {                                                                                        // 31
			BlazeLayout.render('AdminSplash', { main: 'AdminAddProduct' });                                           // 34
		}                                                                                                          // 35
                                                                                                             //
		return action;                                                                                             // 31
	}()                                                                                                         // 31
});                                                                                                          // 31
                                                                                                             //
FlowRouter.route('/admin/product/all', {                                                                     // 38
	name: 'AdminAllProduct',                                                                                    // 39
	action: function () {                                                                                       // 40
		function action() {                                                                                        // 38
			BlazeLayout.render('AdminSplash', { main: 'AdminSeeAllProducts' });                                       // 41
		}                                                                                                          // 42
                                                                                                             //
		return action;                                                                                             // 38
	}()                                                                                                         // 38
});                                                                                                          // 38
                                                                                                             //
/* Single Product Admin Route */                                                                             // 45
                                                                                                             //
FlowRouter.route('/admin/product/:id', {                                                                     // 47
	name: 'AdminSingleProductFull',                                                                             // 48
	action: function () {                                                                                       // 49
		function action() {                                                                                        // 47
			BlazeLayout.render('AdminSplash', { main: 'AdminSingleProductFull' });                                    // 50
		}                                                                                                          // 51
                                                                                                             //
		return action;                                                                                             // 47
	}()                                                                                                         // 47
});                                                                                                          // 47
                                                                                                             //
/* Single Product Route */                                                                                   // 54
                                                                                                             //
FlowRouter.route('/product/:id', {                                                                           // 56
	name: 'single',                                                                                             // 57
	action: function () {                                                                                       // 58
		function action() {                                                                                        // 56
			BlazeLayout.render('singleProduct');                                                                      // 59
		}                                                                                                          // 60
                                                                                                             //
		return action;                                                                                             // 56
	}()                                                                                                         // 56
});                                                                                                          // 56
                                                                                                             //
/* Search Test */                                                                                            // 63
                                                                                                             //
FlowRouter.route('/search', {                                                                                // 65
	name: 'search',                                                                                             // 66
	action: function () {                                                                                       // 67
		function action() {                                                                                        // 65
			BlazeLayout.render('productSearch');                                                                      // 68
		}                                                                                                          // 69
                                                                                                             //
		return action;                                                                                             // 65
	}()                                                                                                         // 65
});                                                                                                          // 65
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections":{"Images.js":["meteor/ostrio:files",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// collections/Images.js                                                                                     //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var FilesCollection;module.import('meteor/ostrio:files',{"FilesCollection":function(v){FilesCollection=v}});
                                                                                                             //
Images = new FilesCollection({                                                                               // 3
  storagePath: '../../../data', // CHECK IF IT WORKS AFTER DEPLOYMENT                                        // 4
  downloadRoute: '/files/images',                                                                            // 5
  collectionName: 'Images',                                                                                  // 6
  chunkSize: 2048 * 2048,                                                                                    // 7
  throttle: 2048 * 2048,                                                                                     // 8
  permissions: 777,                                                                                          // 9
  allowClientCode: true,                                                                                     // 10
  cacheControl: 'public, max-age=31536000',                                                                  // 11
  onbeforeunloadMessage: function () {                                                                       // 12
    function onbeforeunloadMessage() {                                                                       // 12
      return 'Upload is still in progress! Upload will be aborted if you leave this page!';                  // 13
    }                                                                                                        // 14
                                                                                                             //
    return onbeforeunloadMessage;                                                                            // 12
  }(),                                                                                                       // 12
  onBeforeUpload: function () {                                                                              // 15
    function onBeforeUpload(file) {                                                                          // 15
      // Allow upload files under 10MB, and only in png/jpg/jpeg formats                                     // 16
      if (file.size <= 10485760 && /png|jpg|jpeg/i.test(file.ext)) {                                         // 17
        return true;                                                                                         // 18
      } else {                                                                                               // 19
        return 'Please upload image, with size equal or less than 10MB';                                     // 20
      }                                                                                                      // 21
    }                                                                                                        // 22
                                                                                                             //
    return onBeforeUpload;                                                                                   // 15
  }(),                                                                                                       // 15
  downloadCallback: function () {                                                                            // 23
    function downloadCallback(fileObj) {                                                                     // 23
      if (this.params.query.download == 'true') {                                                            // 24
        // Increment downloads counter                                                                       // 25
        Images.update(fileObj._id, { $inc: { 'meta.downloads': 1 } });                                       // 26
      }                                                                                                      // 28
      // Must return true to continue download                                                               // 29
      return true;                                                                                           // 30
    }                                                                                                        // 31
                                                                                                             //
    return downloadCallback;                                                                                 // 23
  }()                                                                                                        // 23
});                                                                                                          // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"Products.js":["meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// collections/Products.js                                                                                   //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});                                  // 1
                                                                                                             //
Products = new Mongo.Collection('products');                                                                 // 4
                                                                                                             //
/* Allows clients to add entries */                                                                          // 6
Products.allow({                                                                                             // 7
	insert: function () {                                                                                       // 8
		function insert() {                                                                                        // 8
			return true;                                                                                              // 9
		}                                                                                                          // 10
                                                                                                             //
		return insert;                                                                                             // 8
	}(),                                                                                                        // 8
	update: function () {                                                                                       // 11
		function update() {                                                                                        // 11
			return true;                                                                                              // 12
		}                                                                                                          // 13
                                                                                                             //
		return update;                                                                                             // 11
	}()                                                                                                         // 11
});                                                                                                          // 7
                                                                                                             //
Meteor.methods({                                                                                             // 16
	deleteProduct: function () {                                                                                // 17
		function deleteProduct(id) {                                                                               // 17
			Products.remove(id);                                                                                      // 18
		}                                                                                                          // 19
                                                                                                             //
		return deleteProduct;                                                                                      // 17
	}()                                                                                                         // 17
});                                                                                                          // 16
                                                                                                             //
/* Collection Atributes */                                                                                   // 22
                                                                                                             //
PictureLink = new SimpleSchema({                                                                             // 24
	picture: {                                                                                                  // 25
		type: String,                                                                                              // 26
		//optional: true,                                                                                          // 27
		autoform: {                                                                                                // 28
			afFieldInput: {                                                                                           // 29
				type: 'fileUpload',                                                                                      // 30
				collection: 'Images'                                                                                     // 31
			}                                                                                                         // 29
		}                                                                                                          // 28
	}                                                                                                           // 25
});                                                                                                          // 24
/*                                                                                                           // 38
ProductsSchema = new SimpleSchema({                                                                          //
	name: {                                                                                                     //
		type: String,                                                                                              //
		label: "Name"                                                                                              //
	},                                                                                                          //
	desc: {                                                                                                     //
		type: String,                                                                                              //
		label: "Description"                                                                                       //
	},                                                                                                          //
	brand: {                                                                                                    //
		type: String,                                                                                              //
		label: "Brand"                                                                                             //
	},                                                                                                          //
	decade: {                                                                                                   //
		type: Number,                                                                                              //
		label: "Decade"                                                                                            //
	},                                                                                                          //
	type: {                                                                                                     //
		type: String,                                                                                              //
		label: "Type"                                                                                              //
	},                                                                                                          //
  	pictures: {                                                                                               //
  		type: [PictureLink],                                                                                     //
  	}                                                                                                         //
});                                                                                                          //
*/                                                                                                           //
                                                                                                             //
ProductsSchema = new SimpleSchema({                                                                          // 67
	ref: {                                                                                                      // 68
		type: String,                                                                                              // 69
		label: "Referência",                                                                                       // 70
		unique: true                                                                                               // 71
	},                                                                                                          // 68
	name: {                                                                                                     // 73
		type: String,                                                                                              // 74
		label: "Nome"                                                                                              // 75
	},                                                                                                          // 73
	brand: {                                                                                                    // 77
		type: String,                                                                                              // 78
		label: "Marca"                                                                                             // 79
	},                                                                                                          // 77
	desc: {                                                                                                     // 81
		type: String,                                                                                              // 82
		label: "Descrição"                                                                                         // 83
	},                                                                                                          // 81
	type: {                                                                                                     // 85
		type: String,                                                                                              // 86
		label: "Tipo"                                                                                              // 87
	},                                                                                                          // 85
	gender: {                                                                                                   // 89
		type: String,                                                                                              // 90
		label: "Género",                                                                                           // 91
		allowedValues: ['Male', 'Female', 'Both']                                                                  // 92
	},                                                                                                          // 89
	season: {                                                                                                   // 94
		type: String,                                                                                              // 95
		label: "Anos"                                                                                              // 96
	},                                                                                                          // 94
	spotlight: {                                                                                                // 99
		type: Boolean,                                                                                             // 100
		label: "Em destaque"                                                                                       // 101
	},                                                                                                          // 99
	available: {                                                                                                // 103
		type: Boolean,                                                                                             // 104
		label: "Disponível"                                                                                        // 105
	},                                                                                                          // 103
	pictures: {                                                                                                 // 108
		type: [PictureLink]                                                                                        // 109
	}                                                                                                           // 108
                                                                                                             //
});                                                                                                          // 67
                                                                                                             //
Products.attachSchema(ProductsSchema);                                                                       // 117
                                                                                                             //
//class="form-control af-file-upload-capture"                                                                // 119
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"server":{"init.js":["meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/init.js                                                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});                                  // 1
                                                                                                             //
Meteor.startup(function () {                                                                                 // 3
  // code to run on server at startup                                                                        // 4
});                                                                                                          // 5
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publish.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/publish.js                                                                                         //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
/* Anounces to clients the collections available */                                                          // 1
/* Can be limited to specific entries in the collection */                                                   // 2
                                                                                                             //
/*Meteor.publish('products', function(){                                                                     // 4
	return Products.find();                                                                                     //
});*/                                                                                                        //
                                                                                                             //
//import Images from 'Images.js';                                                                            // 8
                                                                                                             //
Meteor.publish('singleProduct', function (id) {                                                              // 10
  check(id, String);                                                                                         // 11
  return Products.find({ _id: id });                                                                         // 12
});                                                                                                          // 13
                                                                                                             //
/* Image Testing */                                                                                          // 15
Meteor.publish('files.images.all', function () {                                                             // 16
  return Images.find().cursor;                                                                               // 17
});                                                                                                          // 18
                                                                                                             //
Meteor.publish('files.images.multiple', function (id) {                                                      // 20
  check(id, String);                                                                                         // 21
  var p = Products.findOne({ _id: id });                                                                     // 22
  var imageArray = [];                                                                                       // 23
  for (i = 0; i < p.pictures.length; i++) {                                                                  // 24
    imageArray.push(p.pictures[i].picture);                                                                  // 26
  };                                                                                                         // 27
                                                                                                             //
  return Images.find({ "_id": { "$in": imageArray } }).cursor;                                               // 29
});                                                                                                          // 30
                                                                                                             //
Meteor.publish('singleImage', function (id) {                                                                // 32
  check(id, String);                                                                                         // 33
  var p = Products.findOne({ _id: id });                                                                     // 34
  return Images.find({ _id: p.picture }).cursor;                                                             // 35
});                                                                                                          // 36
                                                                                                             //
/* Search Testing */                                                                                         // 38
Meteor.publish('products', function (search) {                                                               // 39
  check(search, Match.OneOf(String, null, undefined));                                                       // 40
                                                                                                             //
  var query = {},                                                                                            // 42
      projection = { limit: 10, sort: { name: 1 } };                                                         // 42
                                                                                                             //
  if (search) {                                                                                              // 45
    var regex = new RegExp(search, 'i');                                                                     // 46
                                                                                                             //
    query = {                                                                                                // 48
      $or: [{ name: regex }, { brand: regex }, { type: regex }, { decade: regex }]                           // 49
    };                                                                                                       // 48
                                                                                                             //
    projection.limit = 100;                                                                                  // 57
  }                                                                                                          // 58
                                                                                                             //
  return Products.find(query, projection);                                                                   // 60
});                                                                                                          // 61
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"search.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// server/search.js                                                                                          //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
SearchSource.defineSource('products', function (searchText, options) {                                       // 1
                                                                                                             //
  //console.log(options);                                                                                    // 3
                                                                                                             //
  var filter = options;                                                                                      // 5
                                                                                                             //
  var brands = [];                                                                                           // 7
  var types = [];                                                                                            // 8
  var seasons = [];                                                                                          // 9
                                                                                                             //
  for (i = 0; i < filter.brand.length; i++) {                                                                // 11
    brands.push(buildRegExp(filter.brand[i]));                                                               // 13
  }                                                                                                          // 14
  for (i = 0; i < filter.type.length; i++) {                                                                 // 15
    types.push(buildRegExp(filter.type[i]));                                                                 // 17
  }                                                                                                          // 18
  for (i = 0; i < filter.season.length; i++) {                                                               // 19
    seasons.push(filter.season[i]);                                                                          // 21
  }                                                                                                          // 22
                                                                                                             //
  var options = { sort: { isoScore: -1 }, limit: 20 };                                                       // 24
                                                                                                             //
  if (searchText) {                                                                                          // 26
                                                                                                             //
    var selector2 = { $and: [{ name: buildRegExp(filter.name) }, { brand: { $in: brands } }, { type: { $in: types } }, { season: { $in: seasons } }] };
                                                                                                             //
    return Products.find(selector2, options).fetch();                                                        // 35
  } else {                                                                                                   // 36
    return Products.find({}, options).fetch();                                                               // 37
  }                                                                                                          // 38
});                                                                                                          // 39
                                                                                                             //
function buildRegExp(searchText) {                                                                           // 41
  // this is a dumb implementation                                                                           // 42
  var parts = searchText.trim().split(/[ \-\:]+/);                                                           // 43
  return new RegExp("(" + parts.join('|') + ")", "ig");                                                      // 44
}                                                                                                            // 45
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/routes.js");
require("./collections/Images.js");
require("./collections/Products.js");
require("./server/init.js");
require("./server/publish.js");
require("./server/search.js");
//# sourceMappingURL=app.js.map
