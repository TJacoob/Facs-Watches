var require = meteorInstall({"lib":{"routes.js":["meteor/kadira:flow-router",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// lib/routes.js                                                                          //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
var FlowRouter = void 0;                                                                  // 1
module.import('meteor/kadira:flow-router', {                                              // 1
	"FlowRouter": function (v) {                                                             // 1
		FlowRouter = v;                                                                         // 1
	}                                                                                        // 1
}, 0);                                                                                    // 1
FlowRouter.route('/dev', {                                                                // 4
	name: 'dev',                                                                             // 5
	action: function () {                                                                    // 6
		BlazeLayout.render('gallery'); //Testing Area                                           // 7
	}                                                                                        // 8
});                                                                                       // 4
FlowRouter.route('/', {                                                                   // 11
	name: 'home',                                                                            // 12
	action: function () {                                                                    // 13
		FlowRouter.go('index');                                                                 // 14
	}                                                                                        // 15
});                                                                                       // 11
FlowRouter.route('/index', {                                                              // 18
	name: 'index',                                                                           // 19
	action: function () {                                                                    // 20
		BlazeLayout.render('index');                                                            // 21
	}                                                                                        // 22
});                                                                                       // 18
FlowRouter.route('/admin', {                                                              // 25
	name: 'admin',                                                                           // 26
	action: function () {                                                                    // 27
		if (Roles.userIsInRole(Meteor.userId(), 'admin', 'admin')) {                            // 28
			// Substituir por página com estatisticas                                              // 30
			BlazeLayout.render('AdminSplash', {                                                    // 31
				main: 'AdminHome'                                                                     // 31
			});                                                                                    // 31
		} else {                                                                                // 32
			BlazeLayout.render('AdminSplash', {                                                    // 35
				main: 'AdminHome'                                                                     // 35
			});                                                                                    // 35
		}                                                                                       // 36
	}                                                                                        // 38
});                                                                                       // 25
FlowRouter.route('/admin/product/add', {                                                  // 41
	name: 'AdminAddProduct',                                                                 // 42
	action: function () {                                                                    // 43
		if (Roles.userIsInRole(Meteor.userId(), 'admin', 'admin')) {                            // 44
			BlazeLayout.render('AdminSplash', {                                                    // 46
				main: 'AdminAddProduct'                                                               // 46
			});                                                                                    // 46
		} else {                                                                                // 47
			alert("Sem permissão para aceder a esta página.");                                     // 50
			FlowRouter.go('admin');                                                                // 51
		}                                                                                       // 52
	}                                                                                        // 53
});                                                                                       // 41
FlowRouter.route('/admin/product/all', {                                                  // 56
	name: 'AdminAllProduct',                                                                 // 57
	action: function () {                                                                    // 58
		if (Roles.userIsInRole(Meteor.userId(), 'admin', 'admin')) {                            // 59
			BlazeLayout.render('AdminSplash', {                                                    // 61
				main: 'AdminSeeAllProducts'                                                           // 61
			});                                                                                    // 61
		} else {                                                                                // 62
			alert("Sem permissão para aceder a esta página.");                                     // 65
			FlowRouter.go('admin');                                                                // 66
		}                                                                                       // 67
	}                                                                                        // 68
}); /* Single Product Admin Route */                                                      // 56
FlowRouter.route('/admin/product/:id', {                                                  // 73
	name: 'AdminSingleProductFull',                                                          // 74
	action: function () {                                                                    // 75
		if (Roles.userIsInRole(Meteor.userId(), 'admin', 'admin')) {                            // 76
			BlazeLayout.render('AdminSplash', {                                                    // 78
				main: 'AdminSingleProductFull'                                                        // 78
			});                                                                                    // 78
		} else {                                                                                // 79
			alert("Sem permissão para aceder a esta página.");                                     // 82
			FlowRouter.go('admin');                                                                // 83
		}                                                                                       // 84
	}                                                                                        // 85
}); /* Single Product Route */                                                            // 73
FlowRouter.route('/product/:id', {                                                        // 90
	name: 'single',                                                                          // 91
	action: function () {                                                                    // 92
		BlazeLayout.render('singleProduct');                                                    // 93
	}                                                                                        // 94
});                                                                                       // 90
FlowRouter.route('/search', {                                                             // 97
	name: 'search',                                                                          // 98
	action: function () {                                                                    // 99
		BlazeLayout.render('productSearch');                                                    // 100
		$('html, body').animate({                                                               // 101
			scrollTop: $("#productSearchTop").offset().top                                         // 102
		}, 0);                                                                                  // 101
	}                                                                                        // 104
});                                                                                       // 97
FlowRouter.route('/special', {                                                            // 107
	name: 'special',                                                                         // 108
	action: function () {                                                                    // 109
		BlazeLayout.render('special');                                                          // 110
	}                                                                                        // 111
}); //Roles.userIsInRole(ad, 'admin', 'admin')                                            // 107
////////////////////////////////////////////////////////////////////////////////////////////

}]},"collections":{"Images.js":["meteor/ostrio:files",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// collections/Images.js                                                                  //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
var FilesCollection = void 0;                                                             // 1
module.import('meteor/ostrio:files', {                                                    // 1
  "FilesCollection": function (v) {                                                       // 1
    FilesCollection = v;                                                                  // 1
  }                                                                                       // 1
}, 0);                                                                                    // 1
Images = new FilesCollection({                                                            // 5
  storagePath: '../../../data',                                                           // 6
  // CHECK IF IT WORKS AFTER DEPLOYMENT                                                   // 6
  downloadRoute: '/files/images',                                                         // 7
  collectionName: 'Images',                                                               // 8
  chunkSize: 2048 * 2048,                                                                 // 9
  throttle: 2048 * 2048,                                                                  // 10
  permissions: 777,                                                                       // 11
  allowClientCode: true,                                                                  // 12
  cacheControl: 'public, max-age=31536000',                                               // 13
  onbeforeunloadMessage: function () {                                                    // 14
    return 'Upload is still in progress! Upload will be aborted if you leave this page!';
  },                                                                                      // 16
  onBeforeUpload: function (file) {                                                       // 17
    // Allow upload files under 10MB, and only in png/jpg/jpeg formats                    // 18
    if (file.size <= 10485760 && /png|jpg|jpeg/i.test(file.ext)) {                        // 19
      return true;                                                                        // 20
    } else {                                                                              // 21
      return 'Please upload image, with size equal or less than 10MB';                    // 22
    }                                                                                     // 23
  },                                                                                      // 24
  downloadCallback: function (fileObj) {                                                  // 25
    if (this.params.query.download == 'true') {                                           // 26
      // Increment downloads counter                                                      // 27
      Images.update(fileObj._id, {                                                        // 28
        $inc: {                                                                           // 28
          'meta.downloads': 1                                                             // 28
        }                                                                                 // 28
      });                                                                                 // 28
    } // Must return true to continue download                                            // 30
                                                                                          //
                                                                                          //
    return true;                                                                          // 32
  }                                                                                       // 33
});                                                                                       // 5
////////////////////////////////////////////////////////////////////////////////////////////

}],"Products.js":["meteor/meteor",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// collections/Products.js                                                                //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
var Meteor = void 0;                                                                      // 1
module.import('meteor/meteor', {                                                          // 1
	"Meteor": function (v) {                                                                 // 1
		Meteor = v;                                                                             // 1
	}                                                                                        // 1
}, 0);                                                                                    // 1
Products = new Mongo.Collection('products'); /* Allows clients to add entries */          // 4
Products.allow({                                                                          // 7
	insert: function () {                                                                    // 8
		return true;                                                                            // 9
	},                                                                                       // 10
	update: function () {                                                                    // 11
		return true;                                                                            // 12
	}                                                                                        // 13
});                                                                                       // 7
Meteor.methods({                                                                          // 16
	deleteProduct: function (id) {                                                           // 17
		Products.remove(id);                                                                    // 18
	}                                                                                        // 19
}); /* Collection Atributes */                                                            // 16
PictureLink = new SimpleSchema({                                                          // 24
	picture: {                                                                               // 25
		type: String,                                                                           // 26
		//optional: true,                                                                       // 27
		autoform: {                                                                             // 28
			afFieldInput: {                                                                        // 29
				type: 'fileUpload',                                                                   // 30
				collection: 'Images',                                                                 // 31
				uploadTemplate: 'uploadForm'                                                          // 32
			}                                                                                      // 29
		}                                                                                       // 28
	}                                                                                        // 25
});                                                                                       // 24
ProductsSchema = new SimpleSchema({                                                       // 39
	ref: {                                                                                   // 40
		type: String,                                                                           // 41
		label: "Referência",                                                                    // 42
		unique: true                                                                            // 43
	},                                                                                       // 40
	name: {                                                                                  // 45
		type: String,                                                                           // 46
		label: "Nome"                                                                           // 47
	},                                                                                       // 45
	brand: {                                                                                 // 49
		type: String,                                                                           // 50
		label: "Marca"                                                                          // 51
	},                                                                                       // 49
	desc: {                                                                                  // 53
		type: String,                                                                           // 54
		label: "Descrição"                                                                      // 55
	},                                                                                       // 53
	type: {                                                                                  // 57
		type: String,                                                                           // 58
		label: "Tipo"                                                                           // 59
	},                                                                                       // 57
	gender: {                                                                                // 61
		type: String,                                                                           // 62
		label: "Género",                                                                        // 63
		allowedValues: ['Male', 'Female', 'Both']                                               // 64
	},                                                                                       // 61
	season: {                                                                                // 66
		type: String,                                                                           // 67
		label: "Anos"                                                                           // 68
	},                                                                                       // 66
	spotlight: {                                                                             // 71
		type: Boolean,                                                                          // 72
		label: "Em destaque"                                                                    // 73
	},                                                                                       // 71
	special: {                                                                               // 75
		type: Boolean,                                                                          // 76
		label: "Projeto Pessoal"                                                                // 77
	},                                                                                       // 75
	/* available: {                                                                          // 79
 	type: Boolean,                                                                          //
 	label: "Disponível" ,                                                                   //
 	//defaultValue: true ,                                                                  //
 }, */pictures: {                                                                         //
		type: [PictureLink]                                                                     // 85
	}                                                                                        // 84
});                                                                                       // 39
Products.attachSchema(ProductsSchema);                                                    // 89
////////////////////////////////////////////////////////////////////////////////////////////

}],"Users.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// collections/Users.js                                                                   //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
//import { Meteor } from 'meteor/meteor';                                                 // 1
//import { AccountsTemplates } from 'meteor/accounts-base';                               // 2
var pwd = AccountsTemplates.removeField('password');                                      // 4
AccountsTemplates.removeField('email');                                                   // 5
AccountsTemplates.addFields([{                                                            // 6
  _id: "username",                                                                        // 8
  type: "text",                                                                           // 9
  displayName: "username",                                                                // 10
  required: true,                                                                         // 11
  minLength: 5                                                                            // 12
}, {                                                                                      // 7
  _id: 'email',                                                                           // 15
  type: 'email',                                                                          // 16
  required: true,                                                                         // 17
  displayName: "email",                                                                   // 18
  re: /.+@(.+){2,}\.(.+){2,}/,                                                            // 19
  errStr: 'Invalid email'                                                                 // 20
}, {                                                                                      // 14
  _id: 'username_and_email',                                                              // 23
  type: 'text',                                                                           // 24
  required: true,                                                                         // 25
  displayName: "Login"                                                                    // 26
}, pwd, {                                                                                 // 22
  _id: 'date',                                                                            // 30
  type: 'hidden',                                                                         // 31
  autoValue: function () {                                                                // 32
    return new Date();                                                                    // 33
  }                                                                                       // 34
}]);                                                                                      // 29
AccountsTemplates.configure({                                                             // 38
  onSubmitHook: function () {                                                             // 39
    FlowRouter.reload();                                                                  // 40
  }                                                                                       // 41
});                                                                                       // 38
////////////////////////////////////////////////////////////////////////////////////////////

}},"i18n":{"en.i18n.json":function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// i18n/en.i18n.json                                                                      //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
// integrate the fallback language translations 
translations = {};
translations[namespace] = {"nav-search":"Search","nav-personalprojects":"Personal Projects","nav-about":"About us","nav-contacts":"Contacts","index-spotlight":"Spotlight","index-seeallprocucts":"See all products","index-brands":"Our brands","index-aboutus":"About us","index-aboutus-long":"About us English","index-aboutus-end":"About us English","index-contacts":"Get in touch","search-filterby":"Filter by:","search-brand":"Brand","search-type":"Type","search-season":"Season","search-personalproject":"(Personal Project)","special-about-1":"Pode ser-se: jovem, irreverente, iconoclasta e contemporaneamente admirador da tradição, cultor da qualidade e amante do belo? Pode!","special-about-2":"FACS, relógios únicos.","productcard-seemore":"See more about this","loading":"Loading..."};
TAPi18n._loadLangFileObject("en", translations);
TAPi18n._registerServerTranslator("en", namespace);

////////////////////////////////////////////////////////////////////////////////////////////

},"it.i18n.json":function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// i18n/it.i18n.json                                                                      //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["it"] = ["Italian","Italiano"];
if(_.isUndefined(TAPi18n.translations["it"])) {
  TAPi18n.translations["it"] = {};
}

if(_.isUndefined(TAPi18n.translations["it"][namespace])) {
  TAPi18n.translations["it"][namespace] = {};
}

_.extend(TAPi18n.translations["it"][namespace], {"nav-search":"Ricerca","nav-personalprojects":"Progetti Personali","nav-about":"Riguardo a noi","nav-contacts":"Contatti","index-spotlight":"Riflettore","index-seeallprocucts":"Vedi tutti i nostri prodotti","index-brands":"I nostri marchi","index-aboutus":"Riguardo a noi","index-aboutus-long":"About us Italiano","index-aboutus-end":"About us Ital","index-contacts":"Mettetevi in contatto con noi","search-filterby":"Filtra per","search-brand":"Marca","search-type":"Tipo","search-season":"Periodo","search-personalproject":"(Progetto Personale)","special-about-1":"Pode ser-se: jovem, irreverente, iconoclasta e contemporaneamente admirador da tradição, cultor da qualidade e amante do belo? Pode!","special-about-2":"FACS, relógios únicos.","productcard-seemore":"Vedi ulteriori informazioni","loading":"Caricamento..."});
TAPi18n._registerServerTranslator("it", namespace);

////////////////////////////////////////////////////////////////////////////////////////////

},"pt.i18n.json":function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// i18n/pt.i18n.json                                                                      //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["pt"] = ["Portuguese (Portugal)","Português"];
if(_.isUndefined(TAPi18n.translations["pt"])) {
  TAPi18n.translations["pt"] = {};
}

if(_.isUndefined(TAPi18n.translations["pt"][namespace])) {
  TAPi18n.translations["pt"][namespace] = {};
}

_.extend(TAPi18n.translations["pt"][namespace], {"nav-search":"Pesquisar","nav-personalprojects":"FACS by FACS","nav-about":"Sobre nós","nav-contacts":"Contactos","index-spotlight":"Peças em destaque","index-seeallprocucts":"Ver todos os nossos produtos","index-brands":"Marcas","index-aboutus":"A paixão pela mecânica de precisão.","index-aboutus-long":"O prazer de possuir um raro instrumento medidor do tempo. O culto da diferença e a capacidade de nos projectarmos através de objectos excepcionais. A possibilidade de os usar e com eles partilhar os segundos mais notáveis.\nA consciência da individualidade e o gosto pela sua afirmação.","index-aboutus-end":"Para quem vê na procura pela excelência um extraordinário modo de vida.","index-contacts":"Contactos","search-filterby":"Filtrar por:","search-brand":"Marca","search-type":"Tipo","search-season":"Época","search-personalproject":"(Projeto Pessoal)","special-about-1":"Pode ser-se: jovem, irreverente, iconoclasta e contemporaneamente admirador da tradição, cultor da qualidade e amante do belo? Pode!","special-about-2":"FACS, relógios únicos.","productcard-seemore":"Ver mais informação","loading":"A carregar..."});
TAPi18n._registerServerTranslator("pt", namespace);

////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"init.js":["meteor/meteor",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// server/init.js                                                                         //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
var Meteor = void 0;                                                                      // 1
module.import('meteor/meteor', {                                                          // 1
    "Meteor": function (v) {                                                              // 1
        Meteor = v;                                                                       // 1
    }                                                                                     // 1
}, 0);                                                                                    // 1
                                                                                          //
if (Meteor.users.find().count() === 0) {                                                  // 3
    var ad;                                                                               // 4
    ad = Accounts.createUser({                                                            // 5
        username: 'admin',                                                                // 6
        email: 'admin@facswatches.pt',                                                    // 7
        password: '12345678',                                                             // 8
        profile: {                                                                        // 9
            first_name: 'Admin',                                                          // 10
            last_name: 'FACS',                                                            // 11
            company: 'FACS Watches'                                                       // 12
        }                                                                                 // 9
    });                                                                                   // 5
    Roles.addUsersToRoles(ad, ['admin'], 'admin');                                        // 15
    var wb;                                                                               // 17
    wb = Accounts.createUser({                                                            // 18
        username: 'webmaster',                                                            // 19
        email: 'webmaster@facswatches.pt',                                                // 20
        password: '12345678',                                                             // 21
        profile: {                                                                        // 22
            first_name: 'Webmaster',                                                      // 23
            last_name: 'FACS',                                                            // 24
            company: 'FACS Watches'                                                       // 25
        }                                                                                 // 22
    });                                                                                   // 18
    Roles.addUsersToRoles(wb, ['admin'], 'admin');                                        // 28
}                                                                                         // 29
////////////////////////////////////////////////////////////////////////////////////////////

}],"publish.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// server/publish.js                                                                      //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
/* Anounces to clients the collections available */ /* Can be limited to specific entries in the collection */ /*Meteor.publish('products', function(){
                                                                                                               	return Products.find();
                                                                                                               });*/ //import Images from 'Images.js';
Meteor.publish('singleProduct', function (id) {                                           // 10
  check(id, String);                                                                      // 11
  return Products.find({                                                                  // 12
    _id: id                                                                               // 12
  });                                                                                     // 12
}); /* Image Testing */                                                                   // 13
Meteor.publish('files.images.all', function () {                                          // 16
  return Images.find().cursor;                                                            // 17
});                                                                                       // 18
Meteor.publish('files.images.multiple', function (id) {                                   // 20
  check(id, String);                                                                      // 21
  var p = Products.findOne({                                                              // 22
    _id: id                                                                               // 22
  });                                                                                     // 22
  var imageArray = [];                                                                    // 23
                                                                                          //
  for (i = 0; i < p.pictures.length; i++) {                                               // 24
    if (p.pictures[i].picture) imageArray.push(p.pictures[i].picture);                    // 26
  }                                                                                       // 28
                                                                                          //
  ;                                                                                       // 28
  return Images.find({                                                                    // 30
    "_id": {                                                                              // 30
      "$in": imageArray                                                                   // 30
    }                                                                                     // 30
  }).cursor;                                                                              // 30
});                                                                                       // 31
Meteor.publish('singleImage', function (id) {                                             // 33
  check(id, String);                                                                      // 34
  var p = Products.findOne({                                                              // 35
    _id: id                                                                               // 35
  });                                                                                     // 35
  return Images.find({                                                                    // 36
    _id: p.picture                                                                        // 36
  }).cursor;                                                                              // 36
}); /* Search Testing */                                                                  // 37
Meteor.publish('products', function (search) {                                            // 40
  check(search, Match.OneOf(String, null, undefined));                                    // 41
  var query = {},                                                                         // 43
      projection = {                                                                      // 43
    limit: 100,                                                                           // 44
    sort: {                                                                               // 44
      name: 1                                                                             // 44
    }                                                                                     // 44
  };                                                                                      // 44
                                                                                          //
  if (search) {                                                                           // 46
    var regex = new RegExp(search, 'i');                                                  // 47
    query = {                                                                             // 49
      $or: [{                                                                             // 50
        name: regex                                                                       // 51
      }, {                                                                                // 51
        brand: regex                                                                      // 52
      }, {                                                                                // 52
        type: regex                                                                       // 53
      }, {                                                                                // 53
        decade: regex                                                                     // 54
      }]                                                                                  // 54
    };                                                                                    // 49
    projection.limit = 100;                                                               // 58
  }                                                                                       // 59
                                                                                          //
  return Products.find(query, projection);                                                // 61
});                                                                                       // 62
////////////////////////////////////////////////////////////////////////////////////////////

},"search.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// server/search.js                                                                       //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
SearchSource.defineSource('products', function (searchText, options) {                    // 1
  console.log(options);                                                                   // 3
  var filter = options;                                                                   // 5
  var brands = [];                                                                        // 7
  var types = [];                                                                         // 8
  var seasons = [];                                                                       // 9
                                                                                          //
  for (i = 0; i < filter.brand.length; i++) {                                             // 11
    brands.push(buildRegExp(filter.brand[i]));                                            // 13
  }                                                                                       // 14
                                                                                          //
  for (i = 0; i < filter.type.length; i++) {                                              // 15
    console.log(buildRegExp(filter.type[i]));                                             // 17
    console.log(altRegExp(filter.type[i]));                                               // 18
    types.push(altRegExp(filter.type[i]));                                                // 19
  }                                                                                       // 20
                                                                                          //
  for (i = 0; i < filter.season.length; i++) {                                            // 21
    seasons.push(filter.season[i]);                                                       // 23
  }                                                                                       // 24
                                                                                          //
  var options = {                                                                         // 26
    sort: {                                                                               // 26
      isoScore: -1                                                                        // 26
    },                                                                                    // 26
    limit: 100                                                                            // 26
  };                                                                                      // 26
                                                                                          //
  if (searchText) {                                                                       // 28
    var selector2 = {                                                                     // 30
      $and: [{                                                                            // 30
        name: buildRegExp(filter.name)                                                    // 31
      }, {                                                                                // 31
        brand: {                                                                          // 32
          $in: brands                                                                     // 32
        }                                                                                 // 32
      }, {                                                                                // 32
        type: {                                                                           // 33
          $in: types                                                                      // 33
        }                                                                                 // 33
      }, {                                                                                // 33
        season: {                                                                         // 34
          $in: seasons                                                                    // 34
        }                                                                                 // 34
      }]                                                                                  // 34
    };                                                                                    // 30
    return Products.find(selector2, options).fetch();                                     // 37
  } else {                                                                                // 38
    return Products.find({}, options).fetch();                                            // 39
  }                                                                                       // 40
});                                                                                       // 41
                                                                                          //
function buildRegExp(searchText) {                                                        // 43
  // this is a dumb implementation                                                        // 44
  var parts = searchText.trim().split(/[ \-\:]+/);                                        // 45
  return new RegExp("(" + parts.join('|') + ")", "ig");                                   // 46
}                                                                                         // 47
                                                                                          //
function altRegExp(searchText) {                                                          // 49
  // this is a dumb implementation                                                        // 50
  //var parts = searchText.trim().split(/[ \-\:]+/);                                      // 51
  return new RegExp(searchText, "ig");                                                    // 52
}                                                                                         // 53
////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/routes.js");
require("./collections/Images.js");
require("./collections/Products.js");
require("./collections/Users.js");
require("./i18n/en.i18n.json");
require("./i18n/it.i18n.json");
require("./i18n/pt.i18n.json");
require("./server/init.js");
require("./server/publish.js");
require("./server/search.js");
//# sourceMappingURL=app.js.map
