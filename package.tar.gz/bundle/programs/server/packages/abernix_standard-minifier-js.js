(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['abernix:standard-minifier-js'] = {};

})();
